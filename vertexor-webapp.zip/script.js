function sayHello() {
  alert("VERTEXOR welcomes you!");
}